# Bar Register (Render)

## Files
- `index.html` — login, customer screen, bartender register and rating popup.
- `index.js` — Express API, login/session handling, purchase charging and saved data.
- `package.json` — Node dependencies and start command.

## Render setup
Create a **Web Service** from this folder/repository.

- Runtime: Node
- Build command: `npm install`
- Start command: `npm start`

Add these environment variables in Render (use your own private passwords):
- `NODE_ENV` = `production`
- `SESSION_SECRET` = a long random secret (at least 32 characters)
- `OWEN448_PASSWORD` = password you choose for Owen448
- `COLTON448_PASSWORD` = password you choose for Colton448
- `BAR388_PASSWORD` = password you choose for bartender Bar388
- `DATA_DIR` = `/var/data`

Attach a **persistent disk** to the Render service and set its mount path to `/var/data`.
The app writes `register-data.json` there. Without a persistent disk, Render may discard saved balances and ratings when the service restarts or redeploys.

## Starting balances and behavior
Owen448 and Colton448 each start at $100.00 the first time the data file is created. Bar388 is the bartender and does not have a customer balance. Customers can go on/off shift and earn $5.00 per minute while on shift. The bartender selects a customer and charges menu items. A customer who is logged in sees a rating popup after a purchase is recorded.

## Important
This is a small private register. Use strong, unique passwords and do not share the bartender password. The login accounts are configured with Render environment variables, not hardcoded into the source. The data file stores balances, shifts, purchases and ratings.
